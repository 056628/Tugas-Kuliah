class Main {
 
  public static void maain(String[] args) {
    salam();
  }

  static String salam(){
    String teks = "Salam Programmer!";
    System.out.println(teks);
    return teks;
  }
}