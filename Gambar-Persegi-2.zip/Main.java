import java.util.Scanner;
class Main {
   public static void main(String[] args) {
      Scanner input = new Scanner(System.in);
      int hehe= input.nextInt();
      
        for (int i = 0; i < hehe; i++) {
          for (int j = 0; j < hehe; j++) {
            System.out.print("");
          }
          System.out.println("");
        }
  }
}
