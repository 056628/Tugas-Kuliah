class Main {
  public static void main(String[] args) {
    
    String nama = ("Budi");				
    String tanya = ("Apa ") + ("kabar?");	
    String sapa = ("Hai ") + ("Budi");	 
    String kalimat = ("Hai ") + ("Budi, ") + ("Apa kabar?");
    System.out.println(kalimat);
  }
}