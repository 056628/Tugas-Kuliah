class Main {
  public static void main(String[] args) {
    String kalimat = "Saya berkata, \"Rajin belajar, ya!\"";
    System.out.println(kalimat);
  }
}