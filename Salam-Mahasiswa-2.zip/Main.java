class Main {
  public static void main(String[] args) {
    System.out.println("Salam Mahasiswa!");
    System.out.println("Salam Mahasiswa!");
  }
}