public class Main {
    public static void main(String[] args) {
        
        for (int i = 1; i < 21; i++) {
            System.out.println("Saya berjanji akan rajin belajar Java!");
        }
        
    }
}